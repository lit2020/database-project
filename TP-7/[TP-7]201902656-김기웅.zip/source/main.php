<?php session_unset()
?>

<!DOCTYPE html>
<html>
    <head></head>
    <body>
        <h1>전자도서관</h1>
        <button type="button" onclick="location.href='login.html' ">로그인</button>
        <button type="button" onclick="location.href='signup.php' ">회원가입</button>
    </body>
</html>